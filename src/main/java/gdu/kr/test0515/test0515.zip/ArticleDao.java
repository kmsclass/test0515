package gdu.kr.test0515;

public interface ArticleDao {
	void insert();
}
